	create proc DoAfterInsert(@tableName varchar(50),@rptId varchar(20),@userID int ,@deptID int ,@where varchar(1000))
	as
	begin
	--declare @tableName varchar(50)  --param
	--declare @rptId varchar(20)   --param
	--declare @userID int  --param
	--declare @deptID int --param
	--declare @where varchar(1000)--param
	--set @tableName='B_Department'
	--set @rptId='36.1'
	--set @userID=1
	--set @DeptId=1
	--set @where =' and B_Department=''xxx'''

	declare @sqlexec nvarchar(4000)
	declare @userName varchar(50)
	declare @DeptName varchar(50)


	--1.ExcelServer������Ҫ��RCID��ŵ���
	exec GetNewId_s 26,1
	declare @rcid varchar(20)
	declare @maxid int
	select @maxid=maxId from ES_SysId_s where IdName=26 and idDate=convert(varchar(10),getdate(),111)
	set @rcid='rc'+convert(varchar(10),getdate(),112)+REPLICATE('0',5-len(@maxid))+convert(varchar(5),@maxid)

	set @sqlexec='update '+@tableName+' set ExcelServerRCID='''+@rcid+''',ExcelServerRN=1,ExcelServerCN=0,ExcelServerRC1='''',ExcelServerWIID='''',ExcelServerRTID='''+@rptId+''',ExcelServerCHG=0
	  where 1=1 '+@where
	--print @rcid
	 exec(@sqlexec)

	select @userName=UserName from ES_User where userID=@userID
	select @DeptName from ES_Dept where DeptId=@DeptId

	INSERT INTO [dbo].[ES_RepCase]
	([rcId] ,[RtId],[fillDept],[fillDeptName],[fillUser],[fillUserName],[fillDate],[rcDesc] ,[state] ,[lstFiller] ,[lstFillerName],[lstFillDate],
	[backUpdate],[openState],[openBy] ,[openByName] ,[OpenBySesId],[lockState] ,[lockInServer],[noticeState],[setNStateInServer] ,
	[replacerId_fill] ,[replacerName_fill],[replacerId_lstFill] ,[replacerName_lstFill] ,[printTime] ,[wiId],[commitByDataWriter])
	 VALUES
	 (		  @rcid    --rcid
			   ,@rptId --<RtId, nvarchar(20),>
			   ,@DeptId--<fillDept, int,>
			   ,@DeptName--<fillDeptName, nvarchar(50),>
			   ,@UserId--<fillUser, int,>
			   ,@UserName--<fillUserName, nvarchar(50),>
			   ,getdate()--<fillDate, datetime,>
			   ,''--<rcDesc, nvarchar(2000),>
			   ,1--<state, smallint,>
			   ,1--<lstFiller, int,>
			   ,@UserName--<lstFillerName, nvarchar(50),>
			   ,getdate()--<lstFillDate, datetime,>
			   ,0--<backUpdate, smallint,>
			   ,0--<openState, smallint,>
			   ,NULL--<openBy, int,>
			   ,NULL--<openByName, nvarchar(50),>
			   ,NULL--<OpenBySesId, nvarchar(20),>
			   ,0--<lockState, smallint,>
			   ,0--<lockInServer, smallint,>
			   ,0--<noticeState, smallint,>
			   ,0--<setNStateInServer, smallint,>
			   ,0--<replacerId_fill, int,>
			   ,''--<replacerName_fill, nvarchar(50),>
			   ,0--<replacerId_lstFill, int,>
			   ,''--<replacerName_lstFill, nvarchar(50),>
			   ,NULL--<printTime, datetime,>
			   ,''--<wiId, nvarchar(20),>
			   ,0--<commitByDataWriter, smallint,>
	)

	end
